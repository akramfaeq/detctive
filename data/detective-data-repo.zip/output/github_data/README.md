# Detective App — Data Repository

قضايا لعبة المحقق

## الهيكل

```
data/
├── meta.json                    ← رقم آخر تحديث (مهم للكاش)
├── levels/
│   ├── easy/
│   │   ├── list.json            ← قائمة القضايا السهلة
│   │   ├── case_001.json
│   │   └── case_010.json
│   ├── medium/
│   │   ├── list.json
│   │   └── case_011.json → case_020.json
│   └── hard/
│       ├── list.json
│       └── case_021.json → case_030.json
└── special/
    ├── closed_room/
    │   ├── list.json
    │   └── case_cr_001.json
    ├── travel/
    │   ├── list.json
    │   └── case_tr_001.json
    ├── murder/
    ├── theft/
    └── missing/
```

## تسمية الـ IDs

| النوع         | Prefix     | مثال          |
|--------------|------------|---------------|
| سهل          | case_      | case_001      |
| متوسط        | case_      | case_011      |
| صعب          | case_      | case_021      |
| غرفة مغلقة  | case_cr_   | case_cr_001   |
| جرائم السفر  | case_tr_   | case_tr_001   |
| جرائم قتل   | case_mu_   | case_mu_001   |
| سرقة         | case_th_   | case_th_001   |
| مفقودون      | case_ms_   | case_ms_001   |

## عند إضافة قضايا جديدة

**مهم** — حدّث `meta.json` وغيّر رقم `lastUpdate` لأي رقم أكبر.
هذا يخبر التطبيق إنه يجيب البيانات الجديدة بدل الكاش.

```json
{ "lastUpdate": 1700000002 }
```
